<?php
require __DIR__ . "/../DBConnect/DBconnect.php";


if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];

    $stmt = $pdo->prepare("SELECT * FROM kunde WHERE id=:id");

    $stmt->bindParam(":id", $id);
    $stmt->execute();
    $kunde = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['id'];
        $vorname = $_POST['vorname'];
        $nachname = $_POST['nachname'];
        $email = $_POST['email'];
        $telefon = $_POST['telefon'];
    
        
    
    
        // execute prepare with SQL-statement
        $stmt = $pdo->prepare("UPDATE kunde SET vorname = :vorname, nachname = :nachname, email = :email, telefon = :telefon WHERE id = :id");    
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':vorname', $vorname);
        $stmt->bindValue(':nachname', $nachname);
        $stmt->bindValue(':email', $email);
        $stmt->bindValue(':telefon', $telefon);

    
    
    
        $stmt->execute();
    
        header('location:./index.php');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kunde ändern</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>

<h1>Kunde ändern</h1>

<div class="form-container">
    <form action="" method="POST">

        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required value="<?php echo $kunde['id']; ?>">

        <label for="vorname">Vorname:</label>
        <input type="text" id="vorname" name="vorname" required value="<?php echo $kunde['vorname']; ?>">

        <label for="nachname">Nachname:</label>
        <input type="text" id="nachname" name="nachname" required value="<?php echo $kunde['nachname']; ?>">

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required value="<?php echo $kunde['email']; ?>">

        <label for="telefon">Telefonnummer:</label>
        <input type="text" id="telefon" name="telefon" required value="<?php echo $kunde['telefon']; ?>">

        <button type="submit">Kunde ändern</button>
    </form>
</div>

<a href="index.php" class="back-btn">Zurück</a>
</body>
</html>