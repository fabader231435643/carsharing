<?php
require __DIR__ . "/../DBConnect/DBconnect.php";

$stmt = $pdo->prepare('SELECT * FROM marke');
$stmt->execute();
$result_customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];

    $stmt = $pdo->prepare("SELECT * FROM modell WHERE id=:id");

    $stmt->bindParam(":id", $id);
    $stmt->execute();
    $modell = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['id'];
        $marke_id = $_POST['marke_id'];
        $name = $_POST['name'];
    
        
    
    
        // execute prepare with SQL-statement
        $stmt = $pdo->prepare("UPDATE modell SET marke_id = :marke_id, `name` = :name WHERE id = :id");
    
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':marke_id', $marke_id);
        $stmt->bindValue(':name', $name);
    
    
    
        $stmt->execute();
    
        header('location:./index.php');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modell ändern</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>

<h1>Modell ändern</h1>

<div class="form-container">
    <form action="" method="POST">

        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required value="<?php echo $modell["id"]; ?>">

        <label for="marke_id" class="form-label">Marke</label>
            <select class="form-container" id="marke_id" name="marke_id" required value="<?php echo $result_customers['marke_id']; ?>">
                <option value="">Bitte wählen</option>
                <?php foreach ($result_customers as $result): ?>
                    <option value="<?php echo $result['id'] ?>"><?php echo $result['name']?></option>
                <?php endforeach; ?>
            </select>
    

        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required value="<?php echo $modell['name']; ?>">


        

        <button type="submit">Modell ändern</button>
    </form>
</div>

<a href="index.php" class="back-btn">Zurück</a>
</body>
</html>