-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 24. Mrz 2025 um 16:38
-- Server-Version: 10.4.32-MariaDB
-- PHP-Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `carsharing`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `automobil`
--

CREATE TABLE `automobil` (
  `id` int(11) NOT NULL,
  `modell_id` int(11) DEFAULT NULL,
  `kennzeichen` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kunde`
--

CREATE TABLE `kunde` (
  `id` int(11) NOT NULL,
  `vorname` varchar(50) DEFAULT NULL,
  `nachname` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefon` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `marke`
--

CREATE TABLE `marke` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `modell`
--

CREATE TABLE `modell` (
  `id` int(11) NOT NULL,
  `marke_id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `vermietung`
--

CREATE TABLE `vermietung` (
  `id` int(11) NOT NULL,
  `kunde_id` int(11) DEFAULT NULL,
  `automobil_id` int(11) DEFAULT NULL,
  `startdatum` datetime DEFAULT NULL,
  `enddatum` datetime DEFAULT NULL,
  `startkilometer` int(11) DEFAULT NULL,
  `endkilometer` int(11) DEFAULT NULL,
  `preis_pro_km` float DEFAULT NULL,
  `preis_pro_tag` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `automobil`
--
ALTER TABLE `automobil`
  ADD PRIMARY KEY (`id`),
  ADD KEY `modell_id` (`modell_id`);

--
-- Indizes für die Tabelle `kunde`
--
ALTER TABLE `kunde`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `marke`
--
ALTER TABLE `marke`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `modell`
--
ALTER TABLE `modell`
  ADD PRIMARY KEY (`id`),
  ADD KEY `marke_id` (`marke_id`);

--
-- Indizes für die Tabelle `vermietung`
--
ALTER TABLE `vermietung`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kunde_id` (`kunde_id`),
  ADD KEY `automobil_id` (`automobil_id`);

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `automobil`
--
ALTER TABLE `automobil`
  ADD CONSTRAINT `automobil_ibfk_1` FOREIGN KEY (`modell_id`) REFERENCES `modell` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `modell`
--
ALTER TABLE `modell`
  ADD CONSTRAINT `modell_ibfk_1` FOREIGN KEY (`marke_id`) REFERENCES `marke` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `vermietung`
--
ALTER TABLE `vermietung`
  ADD CONSTRAINT `vermietung_ibfk_1` FOREIGN KEY (`kunde_id`) REFERENCES `kunde` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vermietung_ibfk_2` FOREIGN KEY (`automobil_id`) REFERENCES `automobil` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
