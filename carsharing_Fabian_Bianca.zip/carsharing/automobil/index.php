<?php
require __DIR__ . "/../DBConnect/DBconnect.php";

// execute prepare with SQL-statement
$stmt = $pdo->prepare(
    "SELECT
        a.id as id,
        a.kennzeichen, 
        a.modell_id
    FROM automobil a
    LEFT JOIN modell m ON m.id = a.modell_id;"
);

// execute SQL-statement
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Automobil</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../styles/styles.css">
</head>

<body>
<h1>Automobil</h1>
<table>
    <thead>
    <tr>
        <th>Automobil ID</th>
        <th>Modell ID</th>
        <th>Kennzeichen</th>
        <th>Bearbeiten</th>
        <th>Löschen</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($result as $row): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['modell_id']; ?></td>
            <td><?php echo $row['kennzeichen']; ?></td>
            <td><a href="./update.php?id=<?php echo $row['id']; ?>" class="btn update_btn">Bearbeiten</a></td>
            <td><a href="./delete.php?id=<?php echo $row['id']; ?>" class="btn delete_btn">Löschen</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<a href="insert.php" class="add_ski_btn">Automobil hinzufügen</a>
</body>
</html>
