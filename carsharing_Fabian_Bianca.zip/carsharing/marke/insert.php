<?php
require __DIR__ . "/../DBConnect/DBconnect.php";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $name = $_POST['name'];

    


    // execute prepare with SQL-statement
    $stmt = $pdo->prepare("INSERT INTO marke (id, `name`) VALUES (:id, :name)");

    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':name', $name);




    $stmt->execute();

    header('location:./index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marke</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>

<h1>Neue Marke hinzufügen</h1>

<div class="form-container">
    <form action="" method="POST">

        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required>
        
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>


        <button type="submit">Marke hinzufügen</button>
    </form>
</div>

<a href="index.php" class="back-btn">Zurück</a>
</body>
</html>