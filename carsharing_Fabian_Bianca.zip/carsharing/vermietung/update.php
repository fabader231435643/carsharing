<?php
// Stellt eine Verbindung zur Datenbank her
require __DIR__ . "/../DBConnect/DBconnect.php";

// Ruft alle Kunden aus der Datenbank ab
$stmt = $pdo->prepare('SELECT * FROM kunde');
$stmt->execute();
$result_customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ruft alle Automobile aus der Datenbank ab
$stmt = $pdo->prepare('SELECT * FROM automobil');
$stmt->execute();
$result_auto = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Prüft, ob eine ID in der URL vorhanden ist (z.B. edit.php?id=1)
if (isset($_GET['id'])) {
    $id = (int) $_GET['id']; // Konvertiert die ID in einen Integer

    // Holt die bestehende Vermietung aus der Datenbank
    $stmt = $pdo->prepare("SELECT * FROM vermietung WHERE id=:id");
    $stmt->bindParam(":id", $id);
    $stmt->execute();
    $vermietung = $stmt->fetch(PDO::FETCH_ASSOC); // Speichert die Vermietung als Array

    // Prüft, ob das Formular abgeschickt wurde
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Holt die Werte aus dem Formular
        $id = $_POST['id'];
        $kunden_id = $_POST['kunden_id'];
        $automobil_id = $_POST['automobil_id'];
        $startdatum = $_POST['startdatum'];
        $enddatum = $_POST['enddatum'];
        $startkilometer = $_POST['startkilometer'];
        $endkilometer = $_POST['endkilometer'];
        $preis_pro_km = $_POST['preis_pro_km'];
        $preis_pro_tag = $_POST['preis_pro_tag'];

        // Bereitet das SQL-Statement zum Aktualisieren der Vermietung vor
        $stmt2 = $pdo->prepare("UPDATE vermietung SET kunde_id = :kunde_id, automobil_id = :automobil_id,
        startdatum = :startdatum, enddatum = :enddatum, startkilometer = :startkilometer, endkilometer = :endkilometer,
        preis_pro_km = :preis_pro_km, preis_pro_tag = :preis_pro_tag WHERE id = :id");

        // Bindet die Werte an die SQL-Anweisung
        $stmt2->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt2->bindParam(':kunde_id', $kunden_id, PDO::PARAM_INT);
        $stmt2->bindParam(':automobil_id', $automobil_id, PDO::PARAM_INT);
        $stmt2->bindParam(':startdatum', $startdatum, PDO::PARAM_STR);
        $stmt2->bindParam(':enddatum', $enddatum, PDO::PARAM_STR);
        $stmt2->bindParam(':startkilometer', $startkilometer, PDO::PARAM_INT);
        $stmt2->bindParam(':endkilometer', $endkilometer, PDO::PARAM_INT);
        $stmt2->bindParam(':preis_pro_km', $preis_pro_km, PDO::PARAM_INT);
        $stmt2->bindParam(':preis_pro_tag', $preis_pro_tag, PDO::PARAM_INT);

        // Führt die SQL-Anweisung aus, um die Daten zu aktualisieren
        $stmt2->execute();
        
        // Leitet den Benutzer nach dem Speichern zurück zur Hauptseite
        header("LOCATION: ./index.php");
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vermietung ändern</title>

    <!-- Einbindung der Google-Schriftart "Roboto" -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    
    <!-- Verknüpfung mit der externen CSS-Datei für das Styling -->
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>

<!-- Überschrift der Seite -->
<h1>Vermietung ändern</h1>

<!-- Formular-Container für bessere Darstellung -->
<div class="form-container">
    <!-- Formular zum Bearbeiten einer bestehenden Vermietung -->
    <form action="" method="POST">

        <!-- Eingabefeld für die ID der Vermietung -->
        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required value="<?php echo $vermietung['id']; ?>" readonly>

        <!-- Dropdown-Menü zur Auswahl eines Kunden -->
        <label for="kunde_id" class="form-label">Kunde</label>
        <select class="form-container" id="kunde_id" name="kunden_id" required>
            <option value="">Bitte wählen</option>
            <?php foreach ($result_customers as $result): ?>
                <option value="<?php echo $result['id']; ?>" 
                    <?php echo ($result['id'] == $vermietung['kunde_id']) ? 'selected' : ''; ?>>
                    <?php echo $result['nachname']. " " . $result['vorname']; ?>
                </option>
            <?php endforeach; ?>
        </select>

        <!-- Dropdown-Menü zur Auswahl eines Automobils -->
        <label for="automobil_id" class="form-label">Automobil</label>
        <select class="form-container" id="automobil_id" name="automobil_id" required>
            <option value="">Bitte wählen</option>
            <?php foreach ($result_auto as $result): ?>
                <option value="<?php echo $result['id']; ?>" 
                    <?php echo ($result['id'] == $vermietung['automobil_id']) ? 'selected' : ''; ?>>
                    <?php echo $result['kennzeichen']; ?>
                </option>
            <?php endforeach; ?>
        </select>

        <!-- Eingabefeld für das Startdatum der Vermietung -->
        <label for="startdatum">Startdatum:</label>
        <input type="date" id="startdatum" name="startdatum" required value="<?php echo $vermietung['startdatum']; ?>">

        <!-- Eingabefeld für das Enddatum der Vermietung -->
        <label for="enddatum">Enddatum:</label>
        <input type="date" id="enddatum" name="enddatum" required value="<?php echo $vermietung['enddatum']; ?>">

        <!-- Eingabefeld für den Kilometerstand beim Start -->
        <label for="startkilometer">Startkilometer:</label>
        <input type="number" id="startkilometer" name="startkilometer" required value="<?php echo $vermietung['startkilometer']; ?>">

        <!-- Eingabefeld für den Kilometerstand am Ende -->
        <label for="endkilometer">Endkilometer:</label>
        <input type="number" id="endkilometer" name="endkilometer" required value="<?php echo $vermietung['endkilometer']; ?>">

        <!-- Eingabefeld für den Preis pro Kilometer -->
        <label for="preis_pro_km">Preis pro Kilometer:</label>
        <input type="number" id="preis_pro_km" name="preis_pro_km" required value="<?php echo $vermietung['preis_pro_km']; ?>">

        <!-- Eingabefeld für den Preis pro Tag -->
        <label for="preis_pro_tag">Preis pro Tag:</label>
        <input type="number" id="preis_pro_tag" name="preis_pro_tag" required value="<?php echo $vermietung['preis_pro_tag']; ?>">

        <!-- Button zum Speichern der Änderungen -->
        <button type="submit">Vermietung ändern</button>
    </form>
</div>

<!-- Link zum Zurückkehren zur Hauptseite -->
<a href="index.php" class="back-btn">Zurück</a>

</body>
</html>
