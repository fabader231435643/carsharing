<?php
// Stellt eine Verbindung zur Datenbank her
require __DIR__ . "/../DBConnect/DBconnect.php";

// Ruft alle Kunden aus der Datenbank ab
$stmt = $pdo->prepare('SELECT * FROM kunde');
$stmt->execute();
$result_customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ruft alle Automobile aus der Datenbank ab
$stmt = $pdo->prepare('SELECT * FROM automobil');
$stmt->execute();
$result_auto = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Prüft, ob das Formular abgeschickt wurde
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Holt die Werte aus dem Formular
    $id = $_POST['id'];
    $kunden_id = $_POST['kunde_id'];
    $automobil_id = $_POST['automobil_id'];
    $startdatum = $_POST['startdatum'];
    $enddatum = $_POST['enddatum'];
    $startkilometer = $_POST['startkilometer'];
    $endkilometer = $_POST['endkilometer'];
    $preis_pro_km = $_POST['preis_pro_km'];
    $preis_pro_tag = $_POST['preis_pro_tag'];
    
    // Bereitet die SQL-Anweisung zum Einfügen einer neuen Vermietung vor
    $stmt = $pdo->prepare("INSERT INTO vermietung (id, kunde_id, automobil_id, startdatum, enddatum, startkilometer, 
    endkilometer, preis_pro_km, preis_pro_tag) VALUES (:id, :kunde_id, :automobil_id, :startdatum, :enddatum, :startkilometer, 
    :endkilometer, :preis_pro_km, :preis_pro_tag)");

    // Bindet die Werte an die SQL-Anweisung
    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':kunde_id', $kunden_id);
    $stmt->bindValue(':automobil_id', $automobil_id);
    $stmt->bindValue(':startdatum', $startdatum);
    $stmt->bindValue(':enddatum', $enddatum);
    $stmt->bindValue(':startkilometer', $startkilometer);
    $stmt->bindValue(':endkilometer', $endkilometer);
    $stmt->bindValue(':preis_pro_km', $preis_pro_km);
    $stmt->bindValue(':preis_pro_tag', $preis_pro_tag);

    // Führt die SQL-Anweisung aus
    $stmt->execute();

    // Leitet den Benutzer nach dem Speichern zurück zur Hauptseite
    header('location:./index.php');
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vermietung</title>
    
    <!-- Einbindung der Google-Schriftart "Roboto" -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    
    <!-- Verknüpfung mit der externen CSS-Datei für das Styling -->
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>

<!-- Überschrift der Seite -->
<h1>Neue Vermietung hinzufügen</h1>

<!-- Formular-Container für bessere Darstellung -->
<div class="form-container">
    <!-- Formular zum Hinzufügen einer neuen Vermietung -->
    <form action="" method="POST">

        <!-- Eingabefeld für die ID der Vermietung -->
        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required>
        
        <!-- Dropdown-Menü zur Auswahl eines Kunden -->
        <label for="kunde_id" class="form-label">Kunde</label>
        <select class="form-container" id="kunde_id" name="kunde_id" required>
            <option value="">Bitte wählen</option>
            <?php foreach ($result_customers as $result): ?>
                <option value="<?php echo $result['id'] ?>"><?php echo $result['nachname']. " " . $result['vorname']?></option>
            <?php endforeach; ?>
        </select>
        
        <!-- Dropdown-Menü zur Auswahl eines Automobils -->
        <label for="automobil_id" class="form-label">Automobil</label>
        <select class="form-container" id="automobil_id" name="automobil_id" required>
            <option value="">Bitte wählen</option>
            <?php foreach ($result_auto as $result): ?>
                <option value="<?php echo $result['id'] ?>"><?php echo $result['kennzeichen']?></option>
            <?php endforeach; ?>
        </select>

        <!-- Eingabefeld für das Startdatum der Vermietung -->
        <label for="startdatum">Startdatum:</label>
        <input type="date" id="startdatum" name="startdatum" required>

        <!-- Eingabefeld für das Enddatum der Vermietung -->
        <label for="enddatum">Enddatum:</label>
        <input type="date" id="enddatum" name="enddatum" required>

        <!-- Eingabefeld für den Kilometerstand beim Start -->
        <label for="startkilometer">Startkilometer:</label>
        <input type="number" id="startkilometer" name="startkilometer" required>

        <!-- Eingabefeld für den Kilometerstand am Ende -->
        <label for="endkilometer">Endkilometer:</label>
        <input type="number" id="endkilometer" name="endkilometer" required>

        <!-- Eingabefeld für den Preis pro Kilometer -->
        <label for="preis_pro_km">Preis pro Kilometer:</label>
        <input type="number" id="preis_pro_km" name="preis_pro_km" required>

        <!-- Eingabefeld für den Preis pro Tag -->
        <label for="preis_pro_tag">Preis pro Tag:</label>
        <input type="number" id="preis_pro_tag" name="preis_pro_tag" required>

        <!-- Button zum Absenden des Formulars -->
        <button type="submit">Vermietung hinzufügen</button>
    </form>
</div>

<!-- Link zum Zurückkehren zur Hauptseite -->
<a href="index.php" class="back-btn">Zurück</a>

</body>
</html>
