<?php
// Stellt eine Verbindung zur Datenbank her
require __DIR__ . "/../DBConnect/DBconnect.php";

// Bereitet eine SQL-Abfrage vor, um alle Vermietungen mit den zugehörigen Kunden- und Fahrzeugdaten abzurufen
$stmt = $pdo->prepare(
    "SELECT
        v.id as id, 
        v.kunde_id, v.automobil_id,
        v.startdatum, v.enddatum, v.startkilometer, v.endkilometer,
        v.preis_pro_km, v.preis_pro_tag,
        a.kennzeichen, a.modell_id,
        k.nachname, k.vorname
    FROM vermietung v
    LEFT JOIN kunde k ON k.id = v.kunde_id
    LEFT JOIN automobil a ON v.automobil_id = a.id;"
);

// Führt die SQL-Abfrage aus
$stmt->execute();

// Speichert das Ergebnis als assoziatives Array
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vermietung</title>
    
    <!-- Einbindung der Google-Schriftart "Roboto" -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    
    <!-- Verknüpfung mit der externen CSS-Datei für das Styling -->
    <link rel="stylesheet" href="../styles/styles.css">
</head>

<body>

<!-- Hauptüberschrift der Seite -->
<h1>Vermietung</h1>

<!-- Tabelle zur Anzeige der Vermietungsdaten -->
<table>
    <thead>
    <tr>
        <th>Vermietung ID</th>
        <th>Kunde ID</th>
        <th>Automobil ID</th>
        <th>Startdatum</th>
        <th>Enddatum</th>
        <th>Startkilometer</th>
        <th>Endkilometer</th>
        <th>Preis pro km</th>
        <th>Preis pro Tag</th>
        <th>Bearbeiten</th>
        <th>Löschen</th>
    </tr>
    </thead>
    <tbody>
    <!-- Durchläuft das Ergebnis der Datenbankabfrage und erstellt eine Tabellenzeile für jede Vermietung -->
    <?php foreach ($result as $row): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['kunde_id']; ?></td>
            <td><?php echo $row['automobil_id']; ?></td>
            <td><?php echo $row['startdatum']; ?></td>
            <td><?php echo $row['enddatum']; ?></td>
            <td><?php echo $row['startkilometer']; ?></td>
            <td><?php echo $row['endkilometer']; ?></td>
            <td><?php echo $row['preis_pro_km']; ?></td>
            <td><?php echo $row['preis_pro_tag']; ?></td>
            
            <!-- Links zum Bearbeiten und Löschen einer Vermietung -->
            <td><a href="./update.php?id=<?php echo $row['id']; ?>" class="btn update_btn">Bearbeiten</a></td>
            <td><a href="./delete.php?id=<?php echo $row['id']; ?>" class="btn delete_btn">Löschen</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<!-- Link zum Hinzufügen einer neuen Vermietung -->
<a href="insert.php" class="add_ski_btn">Vermietung hinzufügen</a>

</body>
</html>
