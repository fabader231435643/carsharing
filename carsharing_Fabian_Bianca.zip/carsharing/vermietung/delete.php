<?php
// Stellt eine Verbindung zur Datenbank her
require __DIR__ . "/../DBConnect/DBconnect.php";

// Prüft, ob eine ID in der URL übergeben wurde
if (isset($_GET['id'])) {
    // Wandelt die ID in eine Zahl um
    $id = (int) $_GET['id'];

    // Bereitet eine SQL-Anweisung vor, um den Eintrag mit der angegebenen ID zu löschen
    $stmt = $pdo->prepare("DELETE FROM vermietung WHERE ID = :id");

    // Setzt die ID in die SQL-Anweisung ein
    $stmt->bindParam(":id", $id);

    // Führt die SQL-Anweisung aus
    $stmt->execute();

    // Leitet den Benutzer nach dem Löschen zur Hauptseite weiter
    header("Location: ./index.php");
}
